#include <iostream>
#include <string>

using namespace std;

class StringOperations {
private:
    string str1;

public:
    StringOperations()
    {
    
    }

    void inputStrings()
    {
        cout << "Enter the first string: ";
        getline(cin, str1);
    }

    bool operator==(const StringOperations& other) const 
    {
        return str1 == other.str1;
    }

    bool operator!=(const StringOperations& other) const 
    {
        return !(*this == other);
    }

    bool operator>(const StringOperations& other) const 
    {
        return str1 > other.str1;
    }

    bool operator<(const StringOperations& other) const
    {
        return str1 < other.str1;
    }

    bool operator>=(const StringOperations& other) const
    {
        return !(*this < other);
    }

    bool operator<=(const StringOperations& other) const
    {
        return !(*this > other);
    }

    StringOperations operator+(const StringOperations& other) const
    {
        StringOperations result;
        result.str1 = str1 + " " + other.str1;
        return result;
    }

    StringOperations& operator+=(const string& obj) 
    {
        str1 += obj;
        return *this;
    }

    char& operator[](size_t index)
    {
        return str1[index];
    }

    StringOperations& operator=(const StringOperations& other)
    {
        if (this != &other) 
        {
            str1 = other.str1;
        }
        return *this;
    }

    void compareStrings(const StringOperations& other) const 
    {
        cout << "Comparison Results:" << endl;

        if (*this == other)
        {
            cout << "\"" << str1 << "\" == \"" << other.str1 << "\"" << endl;
        }
        else 
        {
            cout << "\"" << str1 << "\" != \"" << other.str1 << "\"" << endl;
        }

        if (*this > other)
        {
            cout << "\"" << str1 << "\" > \"" << other.str1 << "\"" << endl;
        }
        else 
        {
            cout << "\"" << str1 << "\" <= \"" << other.str1 << "\"" << endl;
        }

        if (*this < other)
        {
            cout << "\"" << str1 << "\" < \"" << other.str1 << "\"" << endl;
        }
        else 
        {
            cout << "\"" << str1 << "\" >= \"" << other.str1 << "\"" << endl;
        }

        if (*this >= other) 
        {
            cout << "\"" << str1 << "\" >= \"" << other.str1 << "\"" << endl;
        }
        else 
        {
            cout << "\"" << str1 << "\" < \"" << other.str1 << "\"" << endl;
        }

        if (*this <= other) 
        {
            cout << "\"" << str1 << "\" <= \"" << other.str1 << "\"" << endl;
        }
        else 
        {
            cout << "\"" << str1 << "\" > \"" << other.str1 << "\"" << endl;
        }
    }

    void concatenateStrings(const StringOperations& other)
    {
        StringOperations result = *this + other;
        cout << "Concatenated string: " << result.str1 << endl;
    }

    void appendToString1() 
    {
        *this += " (after)";
        cout << "After appending, the first string is: " << str1 << endl;
    }

    void characterIndexing() 
    {
        if (!str1.empty()) 
        {
            cout << "The first character of the first string is: " << str1[0] << endl;
            (*this)[0] = 'X';
        }
        else 
        {
            cout << "The first string is empty." << endl;
        }
    }

    void assignString2ToString1(const StringOperations& other)
    {
        *this = other;
        cout << "After assignment, the first string is now: " << str1 << endl;
    }

    void displayStrings() const 
    {
        cout << "First string: " << str1 << endl;
    }
};

int main()
{
    StringOperations str1;

    str1.inputStrings();

    cout << "Displaying strings:" << endl;
    str1.displayStrings();

    cout << "Comparing strings:" << endl;
    str1.compareStrings(str1);

    cout << "Concatenating strings:" << endl;
    str1.concatenateStrings(str1);

    cout << "Appending to the first string:" << endl;
    str1.appendToString1();
    str1.displayStrings();

    cout << "Character indexing in the first string:" << endl;
    str1.characterIndexing();
    str1.displayStrings();

    cout << "Assigning the first string to the first:" << endl;
    str1.assignString2ToString1(str1);
    str1.displayStrings();

    return 0;
}
