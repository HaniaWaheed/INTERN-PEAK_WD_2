#include<iostream>
using namespace std;


class Matrix
{
private:
    int rows;
    int columns;
    int** matrix;
public:
    Matrix(int, int); 
    Matrix(const Matrix&); 

    Matrix& operator ++();

    Matrix operator ++(int ignoreMe); 
    Matrix& operator --(); 
    Matrix operator --(int ignoreMe); 
    void setRows(int r) { rows = r; }
    int getRows() const { return rows; }
    void setCol(int c) { columns = c; }
    int getCol() const { return columns; }
    ~Matrix();
    friend istream& operator>>(istream& in, const Matrix& m);
    friend ostream& operator<<(ostream& out, const Matrix& m);
};

Matrix::Matrix(int rowSize, int colSize) {
    rows = rowSize;
    columns = colSize;
    matrix = new int* [rows]; 
    for (int i = 0; i < rows; ++i)
        matrix[i] = new int[columns]; 
}
Matrix::Matrix(const Matrix& m) 
{
    rows = m.rows; 
    columns = m.columns;

    if (m.matrix)
    {
        matrix = new int* [rows];

        for (int i = 0; i < rows; i++)
            matrix[i] = new int[columns];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                matrix[i][j] = m.matrix[i][j];
            }
        }
    }
}
Matrix& Matrix::operator ++() { 

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            this->matrix[i][j] = ++matrix[i][j];
        }
    }
    return *this;
}
Matrix Matrix::operator ++(int ignoreMe) { 
    Matrix temp(rows, columns);
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < columns; j++)
            temp.matrix[i][j] = matrix[i][j]++;
    return temp;
}
Matrix& Matrix::operator --() {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            this->matrix[i][j] = --matrix[i][j];
        }
    }
    return *this;
}
Matrix Matrix::operator --(int ignoreMe) {
    Matrix temp(rows, columns);
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < columns; j++)
            temp.matrix[i][j] = matrix[i][j]--;
    return temp;
}

Matrix ::~Matrix() {
    delete[] * matrix;
}

istream& operator>>(istream& in, const Matrix& m) {
    cout << "Enter the array: " << endl;
    for (int i = 0; i < m.rows; i++) {
        for (int j = 0; j < m.columns; j++) {
            in >> m.matrix[i][j];
        }
    }
    return in;
}

ostream& operator<<(ostream& out, const Matrix& m) {
    out << "Output:" << endl;
    for (int i = 0; i < m.rows; i++) {
        for (int j = 0; j < m.columns; j++) {
            out << m.matrix[i][j] << " ";
        }
        out << endl;
    }
    return out;
}
int main()
{
    cout << "Matrix 1:" << endl;
    Matrix matrix1(2, 2);
    cin >> matrix1;
    cout << matrix1 << endl;
    cout << "++ Pre-operator: " << endl;
    cout << ++matrix1;
    cout << "Post-operator ++ : " << endl;
    cout << matrix1++;
    cout << "After incrementing Post operator++: " << endl;
    cout << matrix1;
    cout << "-- Pre-operator: " << endl;
    cout << --matrix1;
    cout << "Post-operator -- : " << endl;
    cout << matrix1--;
    cout << "After decrementing Post operator--: " << endl;
    cout << matrix1;
    return 0;
}