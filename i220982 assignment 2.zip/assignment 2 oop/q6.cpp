/* Hania Waheef
roll no: 22i-0982
Section C
*/

#include <iostream>

using namespace std;

class Date
{
public:
    int year;
    int month;
    int day;
    int hour;
    int minute;

    Date(int y = 0, int m = 0, int d = 0, int h = 0, int min = 0)
        : year(y), month(m), day(d), hour(h), minute(min)
    {
    
    }

    void setDate(int y, int m, int d, int h, int min) 
    {
        year = y;
        month = m;
        day = d;
        hour = h;
        minute = min;
    }

    void getDate()  
    {
        cout << year << "-" << month << "-" << day << " " << hour << ":" << minute << endl;
    }
};

class RentalReservation
{
private:
    char reservation_id[15]; 
    char customer_name[50];
    char car_make_model[50];
    Date pickup_date;
    Date return_date;
    double rental_duration; 
    double rental_rate;
    double rental_total;
    char additional_services[100]; 
    int customer_age;

    char available_cars[100][50];
    double car_rates[100][2]; 
    int numCars;

    bool validateReservationID(const char* id) const;
    bool validateCarMakeAndModel(const char* model) const;
    void calculateRentalDuration();
    void calculateRentalRate();
    void calculateRentalTotal();
    bool isAlphaNum(char c) const;
    bool isDigit(char c) const;

public:
    RentalReservation(const char* res_id, const char* cust_name, const char* car_model,
        const Date& pickup, const Date& ret, const char* services, int age);

    void getReservationDetails() const;

    void updateReservation(const Date& new_pickup, const Date& new_return,
        const char* new_car_model, const char* new_services);

    void addCarModel(const char* model, double base_rate, double peak_rate);

    void removeCarModel(const char* model);

    RentalReservation(const char* res_id, const char* cust_name, const char* car_model,
        const Date& pickup, const Date& ret, const char* services, int age)
        : customer_age(age), rental_duration(0), rental_rate(0), rental_total(0), numCars(0)
    {
        int i = 0;
        while (res_id[i] != '\0')
        {
            reservation_id[i] = res_id[i];
            i++;
        }
        reservation_id[i] = '\0';

        i = 0;
        while (cust_name[i] != '\0')
        {
            customer_name[i] = cust_name[i];
            i++;
        }
        customer_name[i] = '\0';

        i = 0;
        while (car_model[i] != '\0')
        {
            car_make_model[i] = car_model[i];
            i++;
        }
        car_make_model[i] = '\0';

        pickup_date = pickup;
        return_date = ret;

        i = 0;
        while (services[i] != '\0')
        {
            additional_services[i] = services[i];
            i++;
        }
        additional_services[i] = '\0';

        if (validateReservationID(res_id) && validateCarMakeAndModel(car_model))
        {
            calculateRentalDuration();
            calculateRentalRate();
            calculateRentalTotal();
        }
        else
        {
            cerr << "Invalid reservation details. Please try again." << endl;
        }
    }

    bool validateReservationID(const char* id) const
    {
        int len = 0;
        while (id[len] != '\0')
        {
            len++;
        }
        if (len != 14)
        {
            return false;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (!isAlphaNum(id[i]))
            {
                return false;
            }
        }
        for (int i = 8; i < 10; ++i)
        {
            if (isAlphaNum(id[i]))
            {
                return false; // Must be special characters
            }
        }
        int digitSum = 0;
        for (int i = 10; i < 14; ++i)
        {
            if (!isDigit(id[i]))
            {
                return false;
            }
            digitSum += id[i] - '0';
        }
        return digitSum < 18;
    }

    bool validateCarMakeAndModel(const char* model) const
    {
        for (int i = 0; i < numCars; ++i)
        {
            int j = 0;
            while (model[j] != '\0' && available_cars[i][j] != '\0' && model[j] == available_cars[i][j])
            {
                j++;
            }
            if (model[j] == '\0' && available_cars[i][j] == '\0')
            {
                return true;
            }
        }
        return false;
    }

    void calculateRentalDuration()
    {
        rental_duration = 24; 
    }

    void  calculateRentalRate()
    {
        for (int i = 0; i < numCars; ++i)
        {
            int j = 0;
            while (car_make_model[j] != '\0' && available_cars[i][j] != '\0' && car_make_model[j] == available_cars[i][j])
            {
                j++;
            }
            if (car_make_model[j] == '\0' && available_cars[i][j] == '\0')
            {
                rental_rate = car_rates[i][0];
                return;
            }
        }
    }

    void calculateRentalTotal()
    {
        rental_total = rental_duration * rental_rate;
        int len = 0;
        while (additional_services[len] != '\0')
        {
            len++;
        }
        if (len > 0)
        {
            rental_total += 20; 
        }
    }

    void getReservationDetails() const
    {
        cout << "Reservation ID: " << reservation_id << endl;
        cout << "Customer Name: " << customer_name << endl;
        cout << "Car Make and Model: " << car_make_model << endl;
        cout << "Pickup Date: ";
        pickup_date.getDate();
        cout << "Return Date: ";
        return_date.getDate();
        cout << "Rental Duration (hours): " << rental_duration << endl;
        cout << "Rental Rate (per hour): " << rental_rate << endl;
        cout << "Rental Total: " << rental_total << endl;
        cout << "Additional Services: " << additional_services << endl;
    }

    void updateReservation(const Date& new_pickup, const Date& new_return,
        const char* new_car_model, const char* new_services)
    {
        if (!validateCarMakeAndModel(new_car_model))
        {
            cerr << "Invalid car model. Update failed." << endl;
            return;
        }

        pickup_date = new_pickup;
        return_date = new_return;

        int i = 0;
        while (new_car_model[i] != '\0')
        {
            car_make_model[i] = new_car_model[i];
            i++;
        }
        car_make_model[i] = '\0';

        i = 0;
        while (new_services[i] != '\0')
        {
            additional_services[i] = new_services[i];
            i++;
        }
        additional_services[i] = '\0';

        calculateRentalDuration();
        calculateRentalRate();
        calculateRentalTotal();

        cout << "Reservation updated successfully!" << endl;
    }

    void addCarModel(const char* model, double base_rate, double peak_rate)
    {
        if (numCars < 100)
        {
            int i = 0;
            while (model[i] != '\0')
            {
                available_cars[numCars][i] = model[i];
                i++;
            }
            available_cars[numCars][i] = '\0';
            car_rates[numCars][0] = base_rate;
            car_rates[numCars][1] = peak_rate;
            numCars++;
        }
        else
        {
            cerr << "Cannot add more car models. Maximum limit reached." << endl;
        }
    }

    void removeCarModel(const char* model)
    {
        for (int i = 0; i < numCars; ++i)
        {
            int j = 0;
            while (model[j] != '\0' && available_cars[i][j] != '\0' && model[j] == available_cars[i][j])
            {
                j++;
            }
            if (model[j] == '\0' && available_cars[i][j] == '\0')
            {
                for (int k = i; k < numCars - 1; ++k)
                {
                    int l = 0;
                    while (available_cars[k + 1][l] != '\0')
                    {
                        available_cars[k][l] = available_cars[k + 1][l];
                        l++;
                    }
                    available_cars[k][l] = '\0';
                    car_rates[k][0] = car_rates[k + 1][0];
                    car_rates[k][1] = car_rates[k + 1][1];
                }
                numCars--;
                cout << "Car model removed successfully." << endl;
                return;
            }
        }
        std::cerr << "Car model not found." << endl;
    }

    bool isAlphaNum(char c) const
    {
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
    }

    bool isDigit(char c) const
    {
        return c >= '0' && c <= '9';
    }

    ~RentalReservation()
    {
        cout << "Reservation with ID: " << reservation_id << " is destroyed."<<endl;
    }
};



int main() 
{
    char reservation_id[15];
    char customer_name[50];
    char car_make_model[50];
    char additional_services[100];
    int pickup_year;
    int pickup_month;
    int pickup_day;
    int pickup_hour;
    int pickup_minute;
    int return_year;
    int return_month;
    int return_day;
    int return_hour;
    int return_minute;
    int customer_age;

    cout << "Enter reservation ID: ";
    cin >> reservation_id;
    cout << "Enter customer name: ";
    cin.ignore(); 
    cin.getline(customer_name, 50);
    cout << "Enter car make and model: ";
    cin.getline(car_make_model, 50);
    cout << "Enter pickup date (year month day hour minute): ";
    cin >> pickup_year >> pickup_month >> pickup_day >> pickup_hour >> pickup_minute;
    cout << "Enter return date (year month day hour minute): ";
    cin >> return_year >> return_month >> return_day >> return_hour >> return_minute;
    cout << "Enter additional services (comma-separated): ";
    cin.ignore(); 
    cin.getline(additional_services, 100);
    cout << "Enter customer age: ";
    cin >> customer_age;

    Date pickup(pickup_year, pickup_month, pickup_day, pickup_hour, pickup_minute);
    Date ret(return_year, return_month, return_day, return_hour, return_minute);

    RentalReservation reservation(reservation_id, customer_name, car_make_model,
        pickup, ret, additional_services, customer_age);

    reservation.getReservationDetails();

    int numCars;
    cout << "Enter the number of car models to add: ";
    cin >> numCars;

    for (int i = 0; i < numCars; ++i)
    {
        char model[50];
        double base_rate, peak_rate;
        cout << "Enter car make and model: ";
        cin.ignore();
        cin.getline(model, 50);
        cout << "Enter base rate: ";
        cin >> base_rate;
        cout << "Enter peak rate: ";
        cin >> peak_rate;
        reservation.addCarModel(model, base_rate, peak_rate);
    }

    char carToRemove[50];
    cout << "Enter the car make and model to remove: ";
    cin.ignore(); 
    cin.getline(carToRemove, 50);

    reservation.removeCarModel(carToRemove);

    int new_pickup_year, new_pickup_month, new_pickup_day, new_pickup_hour, new_pickup_minute;
    int new_return_year, new_return_month, new_return_day, new_return_hour, new_return_minute;
    char new_car_make_model[50];
    char new_additional_services[100];

    cout << "Enter new pickup date (year month day hour minute): ";
    cin >> new_pickup_year;
    cin >> new_pickup_month;
    cin >> new_pickup_day;
    cin >> new_pickup_hour;
    cin >> new_pickup_minute;

    cout << "Enter new return date (year month day hour minute): ";
    cin >> new_return_year;
    cin >> new_return_month;
    cin >> new_return_day;
    cin >> new_return_hour;
    cin >> new_return_minute;
    cout << "Enter new car make and model: ";
    cin.ignore(); 
    cin.getline(new_car_make_model, 50);
    cout << "Enter new additional services (comma-separated): ";
    cin.getline(new_additional_services, 100);

    Date new_pickup(new_pickup_year, new_pickup_month, new_pickup_day, new_pickup_hour, new_pickup_minute);
    Date new_return(new_return_year, new_return_month, new_return_day, new_return_hour, new_return_minute);

    reservation.updateReservation(new_pickup, new_return, new_car_make_model, new_additional_services);

    reservation.getReservationDetails();

    return 0;
}
