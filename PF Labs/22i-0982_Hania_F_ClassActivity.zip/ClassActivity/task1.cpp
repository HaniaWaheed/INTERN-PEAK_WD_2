//#include <iostream>
//#include <fstream>
//
//using namespace std;
//
//int main() {
//    // Open the file for writing
//    ofstream file("File1.txt");
//
//    // Check if the file is open
//    if (file.is_open()) {
//        // Write the text to the file
//        file << "Ibn Mas'ud said, \"O tongue! Speak goodness and be rewarded, or remain silent and be safe, lest you become regretful.\" - Source: al-Mu'jam al-Kabir 10300";
//        // Close the file
//        file.close();
//        // Notify the user that the file has been written
//        cout << "File written successfully!" << endl;
//    }
//    else {
//        // Notify the user that the file could not be opened
//        cout << "Error: could not open file!" << endl;
//    }
//    return 0;
//}
