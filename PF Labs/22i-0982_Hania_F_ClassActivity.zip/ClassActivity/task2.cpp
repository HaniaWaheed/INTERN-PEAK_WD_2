//#include <iostream>
//#include <fstream>
//#include <string>
//
//using namespace std;
//
//void displayFileContents(const string& fileName) {
//    ifstream file(fileName);
//    if (file.is_open()) {
//        string line;
//        cout << "File Contents:" << endl;
//        while (getline(file, line)) {
//            cout << line << endl;
//        }
//        file.close();
//    }
//    else {
//        cout << "Error: File '" << fileName << "' not found." << endl;
//    }
//}
//
//int countAlphabets(const string& fileName) {
//    ifstream file(fileName);
//    if (file.is_open()) {
//        char c;
//        int count = 0;
//        while (file.get(c)) {
//            if (isalpha(c)) {
//                count++;
//            }
//        }
//        file.close();
//        return count;
//    }
//    else {
//        cout << "Error: File '" << fileName << "' not found." << endl;
//        return -1;
//    }
//}
//
//int countWords(const string& fileName) {
//    ifstream file(fileName);
//    if (file.is_open()) {
//        string word;
//        int count = 0;
//        while (file >> word) {
//            count++;
//        }
//        file.close();
//        return count;
//    }
//    else {
//        cout << "Error: File '" << fileName << "' not found." << endl;
//        return -1;
//    }
//}
//
//void createAndWriteToFile(const string& fileName, const string& content) {
//    std::ofstream file(fileName);
//    if (file.is_open()) {
//        file << content;
//        file.close();
//        cout << "File written successfully!" << endl;
//    }
//    else {
//        cout << "Error: Could not open file '" << fileName << "' for writing." << endl;
//    }
//}
//
//int main() {
//    string fileName = "File2.txt";
//    string content = "The rose is red.\nA girl is playing there.\nhere is a playground.\nAn aeroplane is in the sky.\nNumbers are not allowed in the password.\n";
//
//    createAndWriteToFile(fileName, content);
//
//    displayFileContents(fileName);
//
//    int alphabetCount = countAlphabets(fileName);
//    if (alphabetCount != -1) {
//        cout << "Number of Alphabets: " << alphabetCount << endl;
//    }
//
//    int wordCount = countWords(fileName);
//    if (wordCount != -1) {
//        cout << "Number of Words: " << wordCount << endl;
//    }
//
//    return 0;
//}
