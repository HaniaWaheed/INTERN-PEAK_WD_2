

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void mergeFiles(const string& file1, const string& file2, const string& mergedFile) {
    ifstream inputFile1(file1);
    ifstream inputFile2(file2);
    ofstream outputFile(mergedFile);

    if (!inputFile1 || !inputFile2 || !outputFile) {
        cout << "Error: Unable to open files for merging." << endl;
        return;
    }

    string line;

    // Merge contents of file1
    while (getline(inputFile1, line)) {
        outputFile << line << endl;
    }

    // Merge contents of file2
    while (getline(inputFile2, line)) {
        outputFile << line << endl;
    }

    cout << "Files merged successfully." << endl;

    // Close all the files
    inputFile1.close();
    inputFile2.close();
    outputFile.close();
}

int main() {
    string file1 = "File1.txt";
    string file2 = "File2.txt";
    string mergedFile = "MergedFile.txt";

    mergeFiles(file1, file2, mergedFile);

    return 0;
}
