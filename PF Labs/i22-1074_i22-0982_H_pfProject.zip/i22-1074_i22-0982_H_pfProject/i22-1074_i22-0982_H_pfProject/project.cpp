

/* //------------------------PF Final Project----------------------------//
    Group members :
                     - Fatima (22i-1074)
                     - Hania Waheed (22i-0982)

*/

// header files 
#include <iostream> // input out stream lib

#include <cstdlib> //std lib 
#include <ctime> // random number generation 


using namespace std;

//Function prototypes
void start(); // start function prototype 
// taking permission ftn from the user
int shoro();
// prototype of function of determining next possible  positions
void Nmoves(char*, int, int);
// Function prototype of  making random numbers 
int Randpos(int*, int*);
// Function prototype to find adjacent 
bool Adj(int, int, int, int);
// Function prototype to check diagonals 
bool Diag(int, int, int, int);
// Function prototype to check row or colums
bool Str(int, int, int, int);
// Function prototype to check that the position is correct or not in matrix
bool ValidPos(int, int);
// Function prototype chessboard displaying 
void displayChessboard(int, int, int, int);
// Function prototype to check position of king is corrct or not 
bool isValidPositionKing(int, int, int, int);

//main ftn 
int main() {
    start(); // calling function to start the whole program 
    return 0; // main ftn ends here 
}

// start function 
void start() {

    string choice;
    if (shoro() == 1) {
        do {
            char obj;
            int r, c;
            char* ptr = &obj;


            // Taking input from the user of piece 
            cout << "Choose one of the piece (k, q, b, r, n): ";
            cin >> obj;
            //input validation 
            while (obj != 'k' && obj != 'q' && obj != 'b' && obj != 'r' && obj != 'n') {
                cout << "Incorrect input of piece. Reenter the piece \n";
                cin >> obj;
            }
            //taking rows and columns input 
            cout << "Enter the row (0-7): ";
            cin >> r;
            cout << "Enter the column (0-7): ";
            cin >> c;

            // calling the validPos function 
            if (ValidPos(r, c)) {
                // the ftn to display the next possible positions 
                Nmoves(ptr, r, c);
            }

            cout << "Do you want to continue? Enter Y/N ";
            cin >> choice;

        } while (choice == "Yes" || choice == "yes" || choice == "YES" || choice == "y" || choice == "Y");
    }
    cout << " Program ended \n Now Do You want to play 2 player Chess game?Y/N " << endl;
    string a;
    cin >> a;


    // char S;
    if (a == "Yes" || a == "yes" || a == "YES" || a == "y" || a == "Y") {
        cout << "Rule: To end the game press 9 " << endl; // to end the game caution 
        srand(time(0));

        int kX;
        int kY;
        int opp1;
        int opp2;
        // first generate random poss. for initial positions
        int f = 0;
        int g = 7;
        int* PTR = &f;
        int* PTR2 = &g;
        kX = Randpos(PTR, PTR2);
        kY = Randpos(PTR, PTR2);
        opp1 = Randpos(PTR, PTR2);
        opp2 = Randpos(PTR, PTR2);

        // deleting/ eleminating the same position of the king and opponent 
        while (kX == opp1 && kY == opp2) {
            opp1 = Randpos(PTR, PTR2);
            opp2 = Randpos(PTR, PTR2);
        }

        // loop for starting the game 
        while (true) {
            // chessboard printing 
            displayChessboard(kX, kY, opp1, opp2);

            // program 
            int s, t;
            do {
                // making a random positions against the king 
                s = Randpos(PTR, PTR2);
                t = Randpos(PTR, PTR2);
            } while (Adj(s, t, kX, kY) || Diag(s, t, kX, kY) ||
                Str(s, t, kX, kY));

            // Now the new position against king
            opp1 = s;
            opp2 = t;

            // checking that the king is killed or not 
            if (Adj(opp1, opp2, kX, kY)) {
                cout << "Game Over! The opponent has trapped the king." << endl;
                break;
            }

            // king's movement 
            int kingmoveX, kingmoveY;
            cout << "Enter the new position for your king (x y): ";
            cin >> kingmoveX;
            int* ptr2;
            ptr2 = &kingmoveX;

            //checking whether the entered number is nine or not 
            if (*ptr2 == 9) {
                cout << "Game ended. ";
                break;
            }
            cin >> kingmoveY;

            //checking whether the entered number is nine or not 
            int* ptr3;
            ptr3 = &kingmoveY;

            if (*ptr3 == 9) {
                cout << "Game ended. ";
                break;
            }

            // doing input validation 
            if (!isValidPositionKing(kX, kY, kingmoveX, kingmoveY)) {
                cout << "Invalid position. Please enter a valid position." << endl;
                continue;
            }

            // finding the adjacent position 
            if (Adj(kingmoveX, kingmoveY, opp1, opp2)) {
                cout << "Game Over! The opponent has trapped the king." << endl;
                break;
            }



            if (isValidPositionKing(kX, kY, kingmoveX, kingmoveY)) {
                // the king's position now 
                kX = kingmoveX;
                kY = kingmoveY;
            }

            // king safety checking 
            bool safe = false;
            for (int l = -1; l <= 1; l++) {
                for (int m = -1; m <= 1; m++) {
                    if (ValidPos(kX + l, kY + m) &&
                        !Adj(kX + l, kY + m, opp1, opp2) &&
                        !Diag(kX + l, kY + m, opp1, opp2) &&
                        !Str(kX + l, kY + m, opp1, opp2)) {
                        safe = true;
                        break;
                    }
                }
                if (safe) {
                    break; // king is safe 
                }
            }

            if (!safe) {
                cout << "Game Over! The king has no way to escape.\n ";
                break;
            }
        }
    }
    else
        cout << "Game ended! " << endl;

}


// Function to calculate and display the next possible positions for the selected chess piece
void Nmoves(char* ptr, int row, int col) {
    cout << "Next moves for (" << row << ", " << col << ") - " << *ptr << ":";
    cout << endl;

    if (*ptr == 'k' || *ptr == 'K') {
        // King possible movements
        int kingM[8][2] = { {-1, -1}, {-1, 0}, {-1, 1}, {0, -1},
                                {0, 1}, {1, -1}, {1, 0}, {1, 1} };
        for (int i = 0; i < 8; i++) {
            int nRow;
            nRow = row + kingM[i][0];
            int nCol;
            nCol = col + kingM[i][1];
            if (nRow >= 0 && nRow < 8 && nCol >= 0 && nCol < 8)
                cout << "(" << nRow << ", " << nCol << ")\n";
        }
    }
    else if (*ptr == 'q' || *ptr == 'Q') {
        // Queen possible movements 

        int bishopMs[4][2] = { {-1, -1}, {-1, 1}, {1, -1}, {1, 1} };
        for (int q = 0; q < 4; q++) {
            for (int u = 1; u < 8; u++) {
                int nextR;
                nextR = row + u * bishopMs[q][0];
                int nextCol;
                nextCol = col + u * bishopMs[q][1];
                if (nextR >= 0 && nextR < 8 && nextCol >= 0 && nextCol < 8)
                    cout << "(" << nextR << ", " << nextCol << ")\n";
                else
                    break;
            }
        }
        // Rook possible movements
        int rook[4][2] = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };
        for (int h = 0; h < 4; h++) {
            for (int b = 1; b < 8; b++) {
                int nextRow;
                nextRow = row + b * rook[h][0];
                int nextCol;
                nextCol = col + b * rook[h][1];
                if (nextRow >= 0 && nextRow < 8 && nextCol >= 0 && nextCol < 8)
                    cout << "(" << nextRow << ", " << nextCol << ")\n";
                else
                    break;
            }
        }
    }
    else if (*ptr == 'b' || *ptr == 'B') {
        // Bishop possible movements
        int bishopMoves[4][2] = { {-1, -1}, {-1, 1}, {1, -1}, {1, 1} };
        for (int d = 0; d < 4; d++) {
            for (int f = 1; f < 8; f++) {
                int nextRow;
                nextRow = row + f * bishopMoves[d][0];
                int nextCol;
                nextCol = col + f * bishopMoves[d][1];
                if (nextRow >= 0 && nextRow < 8 && nextCol >= 0 && nextCol < 8)
                    cout << "(" << nextRow << ", " << nextCol << ")\n";
                else
                    break;
            }
        }
    }
    else if (*ptr == 'r' || *ptr == 'R') {
        // Rock possible movements
        int Moves[4][2] = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };
        for (int x = 0; x < 4; x++) {
            for (int z = 1; z < 8; z++) {
                int nextRow;
                nextRow = row + z * Moves[x][0];
                int nextCol;
                nextCol = col + z * Moves[x][1];
                if (nextRow >= 0 && nextRow < 8 && nextCol >= 0 && nextCol < 8)
                    cout << "(" << nextRow << ", " << nextCol << ")\n";
                else
                    break;
            }
        }
    }
    else if (*ptr == 'n' || *ptr == 'N') {
        // Knight possible movements
        int Moves[8][2] = { {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2},
                                  {1, -2}, {1, 2}, {2, -1}, {2, 1} };
        for (int j = 0; j < 8; j++) {
            int nextRow;
            nextRow = row + Moves[j][0];
            int nextCol;
            nextCol = col + Moves[j][1];
            if (nextRow >= 0 && nextRow < 8 && nextCol >= 0 && nextCol < 8)
                cout << "(" << nextRow << ", " << nextCol << ")\n";
        }
    }
    else {
        cout << "Invalid input.\n";
    }
}




//ftn of random number 
int Randpos(int* a, int* b) {
    return rand() % (*b - *a + 1) + *a;
}
// Ftn finding  adjacent positions 
bool Adj(int a, int y, int b, int y2) {
    return abs(a - b) <= 1 && abs(y - y2) <= 1;
}

// Ftn to determine if the same diagonal
bool Diag(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) == abs(y1 - y2);
}

// Ftn to find if the same row or column
bool Str(int x1, int y1, int x2, int y2) {
    return x1 == x2 || y1 == y2;
}

// Ftn to find if a valid  position 
bool ValidPos(int x, int y)
{
    return (x >= 0 && x < 8 && y >= 0 && y < 8);
}

// print chessboard
void displayChessboard(int kingX, int kingY, int opponentX, int opponentY) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (i == kingX && j == kingY)
                cout << "K ";
            else if (i == opponentX && j == opponentY)
                cout << "Q ";
            else
                cout << ". ";
        }
        cout << "\n";
    }
}
//asking user to start the your next move program
int shoro() {
    int choice;
    cout << "Enter 1 if you want to start the program and 0 if not (1/0) ";
    cin >> choice;
    return choice;
}

// checking whether the king position entered by the user is correct ,not 
bool isValidPositionKing(int X, int Y, int a, int b) {
    if (X + 1 == a && Y == b)
    {
        return true;
    }
    else if (X - 1 == a && Y == b)
    {
        return true;
    }
    else if (X == a && Y + 1 == b)
    {
        return true;
    }
    else if (X == a && Y - 1 == b)
    {
        return true;
    }
    else if (X - 1 == a && Y - 1 == b)
    {
        return true;
    }
    else if (X + 1 == a && Y + 1 == b)
    {
        return true;
    }
    else if (X - 1 == a && Y + 1 == b)
    {
        return true;
    }
    else if (X + 1 == a && Y - 1 == b)
    {
        return true;
    }
    else
    {
        return false;
    }


}

